
# To run this application  you will need to ensure both the frontend and backend apps are running

### Run the Backend application

cd customer-portal/backend

npm run devStart


### un the frontend application
cd customer-portal

npm run dev

Goto your browser and enter the address https://localhost:3000/

